const express = require('express');
const path = require('path');

const app = express();
const PORT = 8080;
const HOST = 'localhost';

// Serve static files from public folder
app.use(express.static(path.join(process.cwd(), 'public')));

app.get("/photos", (request, response) => {
  fetch('https://jsonplaceholder.typicode.com/photos')
    .then(res => res.json())
    .then(photos => {
      response.status(200).json(photos.slice(0, 20));
    })
    .catch(error => {
      response.status(500).json({ error: error.message });
    });
});

app.get("/photos/:id", (request, reply) => {
  fetch(`https://jsonplaceholder.typicode.com/photos/${request.params.id}`)
    .then(response => response.json())
    .then(photo => {
      reply.status(200).json(photo);
    })
    .catch(error => {
      reply.status(500).json({ error: error.message });
    });
});

// Handle 404 for unknown routes
app.use((request, response) => {
  response.status(404).json({ error: 'Route not found' });
});

// Start server
app.listen(PORT, HOST, () => {
  console.log('Working directory:', process.cwd());
  console.log(`Server running at http://${HOST}:${PORT}`);
});