const photoDetails = document.getElementById("photo-details");

document.addEventListener("DOMContentLoaded", () => {
  const photoList = document.getElementById("photo-list");
  fetch("/photos")
    .then((response) => response.json())
    .then((photos) => {
      photos.forEach((photo) => {
        const listItem = document.createElement("li");
        listItem.textContent = photo.title;
        listItem.style.cursor = "pointer";
        listItem.addEventListener("click", () => {
          fetchPhotoDetails(photo.id);
        });
        photoList.appendChild(listItem);
      });
    })
    .catch((error) => {
      console.error("Error fetching photos:", error);
      photoList.innerHTML = "<li>Failed to load photos.</li>";
    });
});

function fetchPhotoDetails(photoId) {
  fetch(`/photos/${photoId}`)
    .then((response) => response.json())
    .then((photo) => {
      displayPhotoDetails(photo);
    })
    .catch((error) => {
      console.error("Error fetching photo details:", error);
      photoDetails.innerHTML = "<p>Failed to load photo details.</p>";
    });
}

function displayPhotoDetails(photo) {
  photoDetails.innerHTML = `
      <p><strong>ID:</strong> ${photo.id}</p>
      <p><strong>Title:</strong> ${photo.title}</p>
      <p><strong>URL:</strong> ${photo.url}</p>
      <p><strong>Thumbnail:</strong> ${photo.thumbnailUrl}</p>
    `;
}
